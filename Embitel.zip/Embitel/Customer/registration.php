<?php

/**
 * Module registration Script
 * @Author: Bratati
 * @Date: 15-19th May, 2017
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Embitel_Customer',
    __DIR__

        );

