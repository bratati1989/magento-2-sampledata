<?php
/**
 * This is installer script
 * @Author :Bratati
 * Date: 15-19th May, 2017
 */

namespace Embitel\Customer\Setup;

use Magento\Customer\Model\Customer;
use Magento\Customer\Setup\CustomerSetup;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\InstallDataInterface;


class InstallData implements InstallDataInterface {


    public function __construct(CustomerSetupFactory $customerSetupFactory) {
         $this->customerSetupFactory = $customerSetupFactory;
    }
    
    /*
     * Add one customer attribute
     * @param: $setup, $context
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context) {
       $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);
            $customerSetup->addAttribute(
                Customer::ENTITY,
                'customer_idprof',
                [
                    'label' => 'Customer Identity Number',
                    'required' => 0,
                    'system' => 0,                             
                    'position' => 100
                ]
            );
            $customerSetup->getEavConfig()->getAttribute('customer', 'customer_idprof')
                ->setData('used_in_forms', ['adminhtml_customer', 'customer_account_create', 'checkout_register'])
                ->save();
        
    }

}
