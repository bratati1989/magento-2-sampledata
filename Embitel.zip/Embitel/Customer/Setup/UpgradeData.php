<?php
/**
 * This is upgrade script 
 * @Author: Bratati
 * @Date: 15-19th May, 2017
 */

namespace Embitel\Customer\Setup;

use Magento\Customer\Api\AddressMetadataInterface;
//use Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;
use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Quote\Setup\QuoteSetupFactory;
use Magento\Sales\Setup\SalesSetupFactory;

/**
 * @codeCoverageIgnore
 */
class UpgradeData implements UpgradeDataInterface
{

  protected $customerSetupFactory;
    
    /**
     * @var QuoteSetupFactory
     */
    protected $quoteSetupFactory;
    
    /**
     * @var SalesSetupFactory
     */
    protected $salesSetupFactory;
    
    /**
     * @var ModuleDataSetupInterface
     */
    protected $setup;
    
    
    
      /**
     * @param EavSetupFactory $eavSetupFactory
     * @param QuoteSetupFactory $quoteSetupFactory
     * @param SalesSetupFactory $salesSetupFactory
     */
    public function __construct(
        CustomerSetupFactory $customerSetupFactory,
        QuoteSetupFactory $quoteSetupFactory,
        SalesSetupFactory $salesSetupFactory
    ) {
         $this->customerSetupFactory = $customerSetupFactory;
        $this->quoteSetupFactory = $quoteSetupFactory;
        $this->salesSetupFactory = $salesSetupFactory;
    }

    
    
    /**
     * {@inheritdoc}
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
       $setup->startSetup();
        /** @var EavSetup $eavSetup */
         
        if (version_compare($context->getVersion(), '1.0.1') < 0) {
            $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);

            $customerSetup->addAttribute(AddressMetadataInterface::ENTITY_TYPE_ADDRESS, 'building', 
                    [
                        'label' => 'Customer Building type(Independence house/Apartment)',
                        'required' => 0,
                        'system' => 0,                             
                        'position' => 200,
                        'visible' => true,
                    ]);
            $this->quoteSetupFactory->create()->addAttribute('quote_address', 'building', ['type' => Table::TYPE_TEXT]);
            $this->salesSetupFactory->create()->addAttribute('order_address', 'building', ['type' => Table::TYPE_TEXT]);
            $customerSetup->getEavConfig()->getAttribute(AddressMetadataInterface::ENTITY_TYPE_ADDRESS, 'building')
                    ->setData('used_in_forms', ['adminhtml_customer_address', 'customer_address_edit'])
                    ->save();
        }
        $setup->endSetup();
    }
}
